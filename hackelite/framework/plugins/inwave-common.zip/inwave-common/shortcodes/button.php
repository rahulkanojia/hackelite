<?php
/*
 * Inwave_Button for Visual Composer
 */
if (!class_exists('Inwave_Button')) {

    class Inwave_Button extends Inwave_Shortcode{

        protected $name = 'inwave_button';

        function register_scripts()
        {
            wp_enqueue_style('iw_button', plugins_url('inwave-common/assets/css/iw-button.css'), array(), INWAVE_COMMON_VERSION);
        }

        function init_params() {
            return array(
                'name' => __("Button", 'inwave-common'),
                'description' => __('Insert a button with some styles', 'inwave-common'),
                'base' => 'inwave_button',
                'icon' => 'iw-default',
                'category' => 'Theme Custom',
                'params' => array(
                    array(
                        "type" => "dropdown",
                        "heading" => "Button style",
                        "param_name" => "style",
                        "value" => array(
                            "Button 1 - Background color" => "button1",
                            "Button 2 - background none, border" => "button2",
                            "Button 3 - background color, round" => "button3",
                        )
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => __("Button Border Color", 'inwave-common'),
                        "param_name" => "border_color_button",
                        "description" => __('Border color for Button', 'inwave-common'),
                        "value" => "",
                        "dependency" => array('element' => 'style', 'value' => 'button2')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Button Text", 'inwave-common'),
                        "param_name" => "button_text",
                        "holder" => "div",
                        "value"=>"Click here"
                    ),
                    array(
                        'type' => 'iw_icon',
                        "heading" => __("Icon Item", 'inwave-common'),
                        "value" => "",
                        "description" => __("Click and select icon of your choice. You can get complete list of available icons here: <a target='_blank' href='http://fortawesome.github.io/Font-Awesome/icons/'>Font-Awesome</a>", 'inwave-common'),
                        "param_name" => "icon_item",
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => "Background Button Style",
                        "param_name" => "bg_style",
                        "value" => array(
                            "Style 1 - Normal Background" => "bg_button_style1",
                            "Style 2 - Gradient Background" => "bg_button_style2",
                        ),
                        "dependency" => array('element' => 'style', 'value' => array('button1', 'button3'))
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => __("Button Background Color", 'inwave-common'),
                        "param_name" => "bg_button",
                        "description" => __('Colored for button background', 'inwave-common'),
                        "value" => "",
                        "dependency" => array('element' => 'bg_style', 'value' => array('bg_button_style1'))
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => __("1st Button Background Color", 'inwave-common'),
                        "param_name" => "bg_button1",
                        "description" => __('First Color for button background', 'inwave-common'),
                        "value" => "",
                        "dependency" => array('element' => 'bg_style', 'value' => array('bg_button_style2'))
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => __("2nd Button Background Color", 'inwave-common'),
                        "param_name" => "bg_button2",
                        "description" => __('Second color for button background', 'inwave-common'),
                        "value" => "",
                        "dependency" => array('element' => 'bg_style', 'value' => array('bg_button_style2'))
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => __("Button Color", 'inwave-common'),
                        "param_name" => "color_button",
                        "description" => __('Color for Button', 'inwave-common'),
                        "value" => "",
                    ),
                    array(
                        'type' => 'dropdown',
                        "heading" => __("Button Font Weight", 'inwave-common'),
                        "description" => __('Button Font Text Weight', 'inwave-common'),
                        "param_name" => "font_weight",
                        "value" => array(
                            "Default" => "",
                            "Extra Bold" => "900",
                            "Bold" => "700",
                            "SemiBold" => "600",
                            "Medium" => "500",
                            "Normal" => "400",
                            "Light" => "300"
                        )
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Button Link", 'inwave-common'),
                        "param_name" => "button_link",
                        "value"=>"#"
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => "Button Width",
                        "param_name" => "button_width",
                        "value" => array(
                            "Width Auto" => "width-auto",
                            "Full Width" => "full-width",
                        )
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("button align", 'inwave-common'),
                        "param_name" => "align",
                        "value" => array(
                            "Default" => "",
                            "Left" => "left",
                            "Right" => "right",
                            "Center" => "center"
                        )
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", 'inwave-common'),
                        "param_name" => "class",
                        "description" => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'inwave-common')
                    ),
                    array(
                        'type' => 'css_editor',
                        'heading' => __( 'CSS box', 'js_composer' ),
                        'param_name' => 'css',
                        // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' ),
                        'group' => __( 'Design Options', 'js_composer' )
                    )
                )
            );
        }

        function init_shortcode($atts, $content = null){
            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = $class = $button_link = $button_text = $icon_item = $align = $css = $style = $bg_style = $bg_button = $bg_button1 = $bg_button2 = $border_color_button = $button_width = $border_icon = $color_button = $font_weight = '';
            extract(shortcode_atts(array(
                'class' => '',
                'button_link' => '',
                'button_text' => '',
                'icon_item' => '',
                'align' => '',
                'css' => '',
                'style' => 'button1',
                'bg_style' => '',
                'bg_button' => '',
                'bg_button1' => '',
                'bg_button2' => '',
                'border_color_button' => '',
                'button_width' => 'width-auto',
                'color_button' => '',
                'font_weight' => '',
            ), $atts));

            return self::inwave_button_shortcode_html($button_link,$button_text,$icon_item,$align,$css,$style,$bg_style,$bg_button,$bg_button1,$bg_button2,$border_color_button,$button_width,$color_button,$font_weight,$border_icon,$class);
        }

        public static function inwave_button_shortcode_html($button_link,$button_text,$icon_item,$align,$css,$style,$bg_style,$bg_button,$bg_button1,$bg_button2,$border_color_button,$button_width,$color_button,$font_weight,$class =''){
            $output='';
            $class .= ' '.$style.' '. vc_shortcode_custom_css_class( $css);
            //$background_style= '';
            //if( $bg_style == 'bg_button_style2') $background_style = 'style="background: rgba(0, 0, 0, 0) linear-gradient(to right bottom , '.$bg_button1.', '.$bg_button2.') repeat scroll 0 0';
            if($align){
                $class.= ' '.$align.'-text';
            }
            $extracss = array();
            if($font_weight){
                $extracss[] .= 'font-weight: '.esc_attr($font_weight);
            }
            if($bg_button){
                $extracss[] .= 'background-color: '.esc_attr($bg_button);
            }
            if( $bg_style == 'bg_button_style2'){
                $extracss[] .= 'background: rgba(0, 0, 0, 0) linear-gradient(to right bottom , '.esc_attr($bg_button1).', '.esc_attr($bg_button2).') repeat scroll 0 0';
            }
            if($color_button){
                $extracss[] .= 'color: '.esc_attr($color_button);
            }
            if($border_color_button){
                $extracss[] .= 'border-color: '.esc_attr($border_color_button);
            }
            ob_start();
            ?>
            <div class="iw-button <?php echo esc_attr($class); ?>">
                <a class="<?php echo esc_attr($button_width); ?>" href="<?php echo esc_url($button_link); ?>" style="<?php echo implode("; ",$extracss); ?>">
                    <span class="button-text"><?php echo esc_html($button_text); echo ($icon_item ? '<i class="'.$icon_item.'"></i>' : ''); ?></span>
                </a>
            </div>
            <?php
            $html = ob_get_contents();
            ob_end_clean();

            return $html;
        }
    }
}

new Inwave_Button;
