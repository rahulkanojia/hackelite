<?php
include_once dirname(__FILE__).'/post-faq.php';



?>
